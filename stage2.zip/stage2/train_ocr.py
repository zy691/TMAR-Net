import argparse
import os
import random
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import transforms
import torch.nn.functional as F
from torch.nn import Module
from PIL import Image
from torch.cuda.amp import autocast, GradScaler
from scipy.ndimage import grey_dilation
from torch.optim.lr_scheduler import StepLR

from swin_transformer_3path_2stft_cnn_conv import SwinUnet
from utils import read_split_data, get_transforms, encode_label, decode_label, char_to_index, MAX_LABEL_LENGTH
import numpy as np
from torchvision.utils import make_grid
from my_dataset import MyDataSet
from my_dataset_multi import MyDataSetMulti

class SinkhornDistance(nn.Module):
    def __init__(self, eps, max_iter, reduction='none'):
        super(SinkhornDistance, self).__init__()
        self.eps = eps
        self.max_iter = max_iter
        self.reduction = reduction

    def forward(self, x, y):
        C = self._cost_matrix(x, y).cuda()  # Wasserstein cost function
        x_points = x.shape[-2]
        y_points = y.shape[-2]
        if x.dim() == 2:
            batch_size = 1
        else:
            batch_size = x.shape[0]

        mu = torch.empty(batch_size, x_points, dtype=torch.float,
                         requires_grad=False).fill_(1.0 / x_points).squeeze().cuda()
        nu = torch.empty(batch_size, y_points, dtype=torch.float,
                         requires_grad=False).fill_(1.0 / y_points).squeeze().cuda()

        u = torch.zeros_like(mu)
        v = torch.zeros_like(nu)
        actual_nits = 0
        thresh = 1e-1

        for i in range(self.max_iter):
            u1 = u 
            u = self.eps * (torch.log(mu + 1e-8) - torch.logsumexp(self.M(C, u, v), dim=-1)) + u
            v = self.eps * (torch.log(nu + 1e-8) - torch.logsumexp(self.M(C, u, v).transpose(-2, -1), dim=-1)) + v
            err = (u - u1).abs().sum(-1).mean()

            actual_nits += 1
            if err.item() < thresh:
                break

        U, V = u, v
        pi = torch.exp(self.M(C, U, V))
        cost = torch.sum(pi * C, dim=(-2, -1))

        if self.reduction == 'mean':
            cost = cost.mean()
        elif self.reduction == 'sum':
            cost = cost.sum()

        return cost, pi, C

    def M(self, C, u, v):
        "Modified cost for logarithmic updates"
        "$M_{ij} = (-c_{ij} + u_i + v_j) / \epsilon$"
        return (-C + u.unsqueeze(-1) + v.unsqueeze(-2)) / self.eps

    @staticmethod
    def _cost_matrix(x, y, p=2):
        "Returns the matrix of $|x_i-y_j|^p$."
        x_col = x.unsqueeze(-2)
        y_lin = y.unsqueeze(-3)
        C = torch.sum((torch.abs(x_col - y_lin)) ** p, -1)
        return C

    @staticmethod
    def ave(u, u1, tau):
        "Barycenter subroutine, used by kinetic acceleration through extrapolation."
        return tau * u + (1 - tau) * u1


class EarlyStopping: 
    def __init__(self, patience=5, min_delta=0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.early_stop = False

    def __call__(self, val_loss):
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss > self.best_loss - self.min_delta:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_loss = val_loss
            self.counter = 0

def print_memory_usage():
    print(f"Allocated: {torch.cuda.memory_allocated() / 1024 ** 2:.2f} MB")
    print(f"Cached: {torch.cuda.memory_reserved() / 1024 ** 2:.2f} MB")

def train_one_epoch(model, optimizer, data_loader, device, epoch):
    import torch
    if torch.cuda.is_available():
        print(f"当前 Batch Size: {args.batch_size}")
        print(f"显存分配: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
        print(f"显存占用峰值: {torch.cuda.max_memory_allocated() / 1024**3:.2f} GB")
        print("Training function called") 
    model.train()
    total_loss = 0
    loss_function = torch.nn.NLLLoss()
    print(f"Data loader length:{len(data_loader)}")  # 打印data_loader的长度

    for i, (images, deinput, targets, imagepaths, labels) in enumerate(data_loader):
        if images is None or targets is None:
            continue 
        images = images.to(device)
        targets = targets.to(device) 
        deinput = deinput.to(device)
        optimizer.zero_grad()
        outputs = model(images, deinput)

        if i % 100 == 0:
            print(epoch,i, imagepaths, labels, "\n", torch.argmax(outputs[0], dim=1), "\n",
                  torch.argmax(targets[0], dim=1))
            pass
        outputs = torch.log(outputs)
        outputs = outputs.reshape(-1, outputs.shape[2])
        targets = torch.argmax(targets, dim=2).reshape(-1)
        loss = loss_function(outputs, targets)  # model.loss1(outputs, targets) + 
        loss.backward()
        optimizer.step()
        total_loss += loss.item() 

        del images, targets, outputs, loss
        torch.cuda.empty_cache()

        if (i + 1) % 100 == 0 or (i + 1) == len(data_loader):
            avg_loss = total_loss / (i + 1)
            print(f"Batch {i + 1}, Average Loss: {avg_loss:.4f}") 
            print(f"Batch {i + 1}, Average Loss: {avg_loss:.4f}")
            print_memory_usage() 

    avg_loss = total_loss / len(data_loader)
    print(f"Epoch [{epoch + 1}], Average Training Loss: {avg_loss:.4f}")  
    print_memory_usage()  
    return avg_loss

def validate(model, data_loader, device):
    print("Validation function called")
    model.eval()
    total_loss = 0
    loss_function = torch.nn.MSELoss()
    print(f"Data loader length: {len(data_loader)}")

    with torch.no_grad():
        for i, (images, detoken, targets, imagepaths, labels) in enumerate(data_loader):
            if images is None or targets is None:
                print(f"Batch {i} is None, skipping.")
                continue

            images, targets = images.to(device), targets.to(device)
            detoken = detoken.to(device=device)
            try:
                with torch.amp.autocast('cuda'):
                    outputs = model(images, detoken)

                    loss = loss_function(outputs, targets)
                    total_loss += loss.item()
            except Exception as e:
                print(f"Error during validation in batch {i}: {e}")
            del images, targets, outputs, loss
            torch.cuda.empty_cache()  

            if (i + 1) % 100 == 0 or (i + 1) == len(data_loader):
                print_memory_usage()  

    avg_loss = total_loss / len(data_loader)
    print(f"Validation Loss: {avg_loss:.4f}")
    print_memory_usage()  
    return avg_loss

def filter_files(directory, exclude_file="7081.jpg", extensions=('.jpg', '.jpeg', '.png', '.bmp')):
    if not isinstance(directory, str):
        raise TypeError(f"Expected string for directory, got {type(directory)}")

    return [
        os.path.join(directory, f) for f in os.listdir(directory)
        if os.path.isfile(os.path.join(directory, f))
           and os.path.splitext(f)[-1].lower() in extensions
           and f != exclude_file
    ]

def create_dataset(image_dir, label_path, transform, skip_images=[]):
    image_files = [f for f in os.listdir(image_dir) if f.endswith(('.jpg', '.jpeg', '.png', '.bmp'))]
    labels = []
    with open(label_path, 'r', encoding='utf-8') as f:
        content = f.readlines()
    for line in content:
        labels.append(line.strip())
    print(f"Number of images: {len(image_files)}")
    print(f"Number of labels: {len(labels)}")

    if len(image_files) != len(labels):
        raise ValueError("图像文件数量和标签数量不一致！请检查数据。")

    filtered_image_files = []
    filtered_labels = []

    for i in range(len(labels)):
        img_file = str(i + 1) + ".jpg"

        img_path = os.path.join(image_dir, img_file)
        with Image.open(img_path) as img:
            width, height = img.size
            if width != 384 or height != 64:  
                print(f"Skipping image due to size mismatch: {img_file}, size: {width}x{height}")
                continue
        filtered_image_files.append(img_path)
        filtered_labels.append(labels[i].rstrip())  

    print(f"Number of images after filtering: {len(filtered_image_files)}")

    if len(filtered_image_files) != len(filtered_labels):
        raise ValueError("过滤后的图像和标签数量不一致！")
    return MyDataSetMulti(images=filtered_image_files, labels=filtered_labels, transform=transform)

def check_images_and_labels(image_path, label_file):
    image_files = sorted([f for f in os.listdir(image_path) if f.endswith('.jpg')])
    with open(label_file, 'r', encoding='utf-8') as f:
        labels = f.readlines()

    if len(image_files) != len(labels):
        print("图像文件数和标签数不匹配！")

def main(args):    
    import os
    from my_dataset_multi import MyDataSetMulti
    
    assert os.path.exists(args.train_data_path), f"训练数据路径不存在: {args.train_data_path}"
    assert os.path.exists(args.train_label_path), f"训练标签文件不存在: {args.train_label_path}"
    assert os.path.exists(args.val_data_path), f"验证数据路径不存在: {args.val_data_path}"
    assert os.path.exists(args.val_label_path), f"验证标签文件不存在: {args.val_label_path}"

    data_transform = transforms.Compose([
        transforms.Lambda(lambda x: x.convert('RGB') if x.mode != 'RGB' else x),
        transforms.GaussianBlur(kernel_size=5, sigma=(0.1, 10.0)),
        transforms.RandomRotation(degrees=5),
        transforms.ToTensor(),
    ])

    train_folders = ["single_swin_train"] + [f"font{i}" for i in range(1, 22)]
    
    with open(args.train_label_path, 'r', encoding='utf-8') as f:
        train_labels_raw = [line.strip() for line in f.readlines()]

    train_image_paths, train_labels = [], []
    print(f"正在汇聚域适应训练数据 (Seed: {args.seed})...")
    
    for folder_name in train_folders:
        folder_path = os.path.join(args.train_data_path, folder_name)
        if not os.path.exists(folder_path):
            print(f"⚠️ 警告：找不到文件夹 {folder_path}，已跳过")
            continue
            
        for i in range(1, len(train_labels_raw) + 1):
            img_path_png = os.path.join(folder_path, f"{i}.png")
            img_path_jpg = os.path.join(folder_path, f"{i}.jpg")
            
            img_path = img_path_png if os.path.exists(img_path_png) else img_path_jpg

            if os.path.exists(img_path) and (i-1) < len(train_labels_raw):
                train_image_paths.append(img_path)
                train_labels.append(train_labels_raw[i-1])
                
    print(f"✅ 训练集构建完毕！共加载 {len(train_image_paths)} 张图片。")

    print("\n" + "="*50)
    print("⚠️ 训练前防呆抽查 (Sanity Check)：请肉眼核对图像与标签是否匹配！")
    import random
    check_indices = random.sample(range(len(train_image_paths)), 3)
    for idx in check_indices:
        print(f"👉 图像路径: {train_image_paths[idx]}")
        print(f"📝 绑定标签: {train_labels[idx]}\n")
    print("="*50 + "\n")

    with open(args.val_label_path, 'r', encoding='utf-8') as f:
        val_labels_raw = [line.strip() for line in f.readlines()]
        
    val_image_paths, val_labels = [], []
    valid_images = [f for f in os.listdir(args.val_data_path) if f.endswith(('.jpg', '.png'))]
    valid_images.sort(key=lambda x: int(x.split('.')[0]))
    
    for i, img_name in enumerate(valid_images):
        if i < len(val_labels_raw):
            img_path = os.path.join(args.val_data_path, img_name)
            val_image_paths.append(img_path)
            val_labels.append(val_labels_raw[i])
            
    print(f"✅ 验证集构建完毕！共加载 {len(val_image_paths)} 张纯净目标字体图片。")

    train_dataset = MyDataSetMulti(images=train_image_paths, labels=train_labels, transform=data_transform)
    val_dataset = MyDataSetMulti(images=val_image_paths, labels=val_labels, transform=data_transform)

    train_loader = DataLoader(dataset=train_dataset, batch_size=args.batch_size, shuffle=True, pin_memory=True, num_workers=0)
    val_loader = DataLoader(dataset=val_dataset, batch_size=args.batch_size, shuffle=False, pin_memory=True, num_workers=0, drop_last=True)

    batch_size = args.batch_size
    nw = min([os.cpu_count(), batch_size if batch_size > 1 else 0, 8])
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    max_label_length = MAX_LABEL_LENGTH
    num_classes_per_character = len(char_to_index)

    model = SwinUnet()
    
    if os.path.exists(args.base_model):
        print(f"🚀 正在加载基础模型: {args.base_model}，开启热启动！")
        model.load_state_dict(torch.load(args.base_model))
    else:
        print(f"⚠️ 未找到基础模型 {args.base_model}，将从零开始训练。")
    
    model = model.to(device)

    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=5E-2)
    scheduler = StepLR(optimizer, step_size=3, gamma=0.9)  
    best_val_loss = float('inf')

    all_train_losses = []
    all_val_losses = []
    early_stopping = EarlyStopping(patience=5, min_delta=0.001)

    save_last_path = f"checkpoints/{args.save_prefix}_last_seed_{args.seed}.pth"
    save_best_path = f"checkpoints/{args.save_prefix}_best_seed_{args.seed}.pth"

    for epoch in range(args.epochs): 
        print(f"Starting epoch {epoch + 1}")
        
        train_loss = train_one_epoch(model, optimizer, train_loader, device, epoch)
        all_train_losses.append(train_loss)

        val_loss = validate(model, val_loader, device)
        all_val_losses.append(val_loss) 
        
        torch.save(model.state_dict(), save_last_path)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), save_best_path)
            print(f"🎉 发现新巅峰！最佳模型已更新，当前验证 Loss: {best_val_loss:.6f}")
        
        print(f"当前轮次模型已保存至 {save_last_path}")
        
        scheduler.step()
        print(f"Finished epoch {epoch + 1}")
        
    plt.plot(all_train_losses, label='Training Loss')
    plt.plot(all_val_losses, label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss over Epochs')
    plt.legend()
    plt.show()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=3)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--lr', type=float, default=1.0e-5)
    parser.add_argument('--split-ratio', type=float, default=0.2)
    parser.add_argument('--device', help='device id (i.e. cuda:0 or cpu)', default='cuda:0')
    parser.add_argument('--seed', type=str, required=True, help='当前训练的种子数')
    parser.add_argument('--base-model', type=str, required=True, help='基础模型权重路径')
    parser.add_argument('--save-prefix', type=str, required=True, help='保存模型的前缀 (如 da_single)')
    parser.add_argument('--train-data-path', type=str, required=True, help='当前Seed的训练集根目录')
    parser.add_argument('--train-label-path', type=str, default="/data/yyhh/swin_transformer/data/labels/train_labels.txt")
    parser.add_argument('--val-data-path', type=str, default="/data/yyhh/swin_transformer/data/images/single_Domain_Adaptation/val_train")
    parser.add_argument('--val-label-path', type=str, default="/data/yyhh/swin_transformer/data/labels/val_labels.txt")
    
    args = parser.parse_args()
    main(args)
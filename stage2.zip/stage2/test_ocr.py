import torch
import os
import sys
import argparse
from torchvision import transforms
from os import listdir
from os.path import join
from swin_transformer_3path_2stft_cnn_conv import SwinUnet
from utils import encode_label, decode_label, index_to_char, MAX_LABEL_LENGTH
from sklearn.metrics import accuracy_score
import numpy as np
from my_dataset import MyDataSet
from torch.utils.data import DataLoader
from PIL import Image

def load_model_weights(model, weights_path, device):
    try:
        state_dict = torch.load(weights_path, map_location=device, weights_only=True)
        model.load_state_dict(state_dict, strict=False)
        print("权重文件加载成功。")
    except Exception as e:
        print(f"加载权重文件时出错: {e}")

def greedy_decoder(model, enc_input, start_symbol):
    enc_outputs = model.swin_unet(enc_input) # enc_outputs: [1, seq_len, 512]
    dec_input = torch.zeros(1,1)

    flag = True
    i=0
    while flag:
        if i==0:
            dec_input=start_symbol.cuda()
        else:
            next_symbol=torch.unsqueeze(next_symbol,dim=0).cuda()
            dec_input = torch.cat([dec_input.detach(), next_symbol], 1)

        dec_outputs = model.mytrans(enc_outputs, dec_input)
        next_symbol = torch.argmax(dec_outputs[:,-1,:], dim=1)

        if next_symbol.item() == 3 and i != 0 or i == 23:
            flag = False
        i+=1
        
    pred = decode_label(dec_input[:, 1:])
    return pred

def main():
    parser = argparse.ArgumentParser(description="评估满文识别模型")
    parser.add_argument('--model-path', type=str, required=True, help='模型权重文件的路径')
    parser.add_argument('--image-dir', type=str, required=True, help='当前 Seed 生成图像的根目录 (包含 font1-font8)')
    parser.add_argument('--output-dir', type=str, required=True, help='结果 TXT 保存的目标文件夹路径')
    parser.add_argument('--save-prefix', type=str, default='result', help='保存 txt 结果文件的前缀')
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    transform = transforms.Compose([
        transforms.Lambda(lambda x: x.convert('RGB') if x.mode != 'RGB' else x),
        transforms.ToTensor(),
    ])

    model = SwinUnet()
    print(f"正在加载模型: {args.model_path}")
    load_model_weights(model, args.model_path, device)    
    model.to(device).eval()  

    test_tasks = [
        {"data": os.path.join(args.image_dir, f"font{i}"), "label": "data/labels/test3_labels.txt", "name": f"Font_{i}"} 
        for i in range(1, 9)
    ]

    os.makedirs(args.output_dir, exist_ok=True)

    for task in test_tasks:
        output_filename = os.path.join(args.output_dir, f"{args.save_prefix}_{task['name']}.txt")
        sys.stdout = open(output_filename, "w", encoding="utf-8")
        
        print(f"=== 开始评估测试集: {task['name']} ===")

        with open(task['label'], 'r', encoding="utf-8") as f:
            real_labels = f.read().splitlines()
        print(f"标签数量: {len(real_labels)}")

        image_folder = task['data']
        valid_images = [f for f in os.listdir(image_folder) if f.endswith(('.png', '.jpg', '.jpeg'))]
        image_paths = [os.path.join(image_folder, f) for f in sorted(valid_images, key=lambda x: int(x.split('.')[0]))]
        print(f"原始图像数量：{len(image_paths)}")

        if len(image_paths) > 1 and "17000" in os.path.basename(image_paths[0]):
            image_paths = image_paths[1:]
            print(f"✅ 已自动剔除 Task 3 的起始占位图(17000.png)，当前有效图像起点: {os.path.basename(image_paths[0])}")

        if len(image_paths) != len(real_labels):
            print(f"⚠️ 警告：图像数量({len(image_paths)})与标签数量({len(real_labels)})不一致。已自动截断对齐！")
            min_len = min(len(image_paths), len(real_labels))
            image_paths = image_paths[:min_len]
            real_labels = real_labels[:min_len]

        val_dataset = MyDataSet(images=image_paths, labels=real_labels, transform=transform)
        val_loader = DataLoader(dataset=val_dataset, batch_size=1, shuffle=False)

        total_correct = 0  
        predicted_labels = []  
        errors = []
        
        for i, (images, real_label_batch, detoken, imagepath, labels) in enumerate(val_loader):
            images = images.to(device)
            detoken = torch.zeros((1, 1))
            detoken[0, 0] = 2
            detoken = detoken.to(device)

            with torch.no_grad():
                pred = greedy_decoder(model, images, start_symbol=detoken)
                predicted_labels.append(pred)
                
                print(f"图像: {image_paths[i]}, 真实标签: {labels[0]}, 预测标签: {pred}")
                
                if pred == labels[0]:
                    total_correct += 1
                else:
                    errors.append(i)

        accuracy = accuracy_score(real_labels, predicted_labels)
        print(f"测试集 {task['name']} 最终准确率 Accuracy: {accuracy}")
        print("错误样本索引列表 errors:", errors)

        sys.stdout.close()
        sys.stdout = sys.__stdout__
        print(f"已完成 {task['name']} 的测试，结果已写入 {output_filename}")

    print("🎉 所有测试集全部自动评估完毕！")

if __name__ == '__main__':
    main()
import os
import torch

EXP_NAME = "Vanilla_U-Net_sn_gan"         
SEED = 42                           

USE_SKELETON = False                     
USE_DISCRIMINATOR = True              
USE_KEYPOINT_WEIGHT = False         

TRAIN_IMAGE_DIR = "fontimages22"  
LABEL_FILE = "wordrandom.txt"    

TEST_IMAGE_DIR_1 = "fontimagestest1"    
TEST_IMAGE_DIR_2 = "fontimagestest2"

CHECKPOINT_DIR = f"outputs/{EXP_NAME}/checkpoints"
SAMPLE_DIR = f"outputs/{EXP_NAME}/samples"
EVALUATION_DIR = f"outputs/{EXP_NAME}/evaluation_results/epoch_best"

IMAGE_WIDTH = 384                 
ROW_HEIGHT = 64                         

TRAIN_TOTAL_ROWS = 22                           

TEST_TOTAL_ROWS = 5               
TEST_TARGET_ROW = 0                     
TEST_STYLE_START_ROW = 1                  
TEST_STYLE_END_ROW = 5              

TRAIN_VALID_HEIGHTS = [ROW_HEIGHT, ROW_HEIGHT * TRAIN_TOTAL_ROWS] 
TEST_VALID_HEIGHTS = [ROW_HEIGHT, ROW_HEIGHT * TEST_TOTAL_ROWS]   

TOTAL_WORDS = 20000                  

TRAIN_WORDS_START = 0
TRAIN_WORDS_END = 15000

VAL_WORDS_START = 15000
VAL_WORDS_END = 17000

TEST_WORDS_START = 17000
TEST_WORDS_END = 20000

MAX_LABEL_LENGTH = 22               
LABEL_COLUMN_ROMAN = 0                
LABEL_COLUMN_MANCHU = 1       

GENERATOR_INPUT_CHANNELS = 3       
GENERATOR_OUTPUT_CHANNELS = 3      
GENERATOR_DIMS = [96, 192, 384, 768]     
GENERATOR_DEPTHS = [3, 3, 9, 3]           
GENERATOR_DROP_PATH_RATE = 0.1           

DISCRIMINATOR_INPUT_CHANNELS = 6       
DISCRIMINATOR_BASE_CHANNELS = 64

NUM_EPOCHS = 300               
BATCH_SIZE = 16               
NUM_WORKERS = 4             

LR_G = 1.5e-4    
LR_D = 1.5e-4
BETAS = (0.5, 0.9)                 

LAMBDA_L1 = 20.0             
LAMBDA_PERCEPTUAL = 0.1                

N_CRITIC = 1                          
GRAD_CLIP_MAX_NORM = 0.5         

USE_AMP = True               

LR_SCHEDULER_T_MAX = 200      
LR_SCHEDULER_ETA_MIN = 1e-6        

LOG_INTERVAL = 50                 

NUM_SAMPLES = 4  


SAVE_INTERVAL = 2        
SAMPLE_INTERVAL = 2      
RESUME_FROM = None # f"outputs/{EXP_NAME}/checkpoints/best_model.pth"  
RESUME_START_EPOCH = 0          ）

USE_PERSPECTIVE = True            
PERSPECTIVE_DISTORTION_SCALE = 0.1   

USE_GAUSSIAN_BLUR = True     
GAUSSIAN_KERNEL_SIZE = 5        
GAUSSIAN_SIGMA_MIN = 0.1               
GAUSSIAN_SIGMA_MAX = 10.0             

USE_ROTATION = True              
ROTATION_DEGREES = 5                     

USE_TRIM = True                        
TRIM_PROBABILITY = 0.1        

SIMPLE_TRANSFORM_PROBABILITY = 0.2     

USE_GRID_DISTORTION = None             
GRID_DISTORTION_PROB = 0.3          
GRID_DISTORTION_LIMIT = 0.15        

TASK1_NAME = "style_generalization"
TASK1_DESCRIPTION = "风格泛化：见过的单词，没见过的风格"
TASK1_WORDS_START = 0         
TASK1_WORDS_END = 500
TASK1_STYLE_SOURCE = "test" 

TASK2_NAME = "word_generalization"
TASK2_DESCRIPTION = "单词泛化：没见过的单词，见过的风格"
TASK2_WORDS_START = 17000 
TASK2_WORDS_END = 17500
TASK2_STYLE_SOURCE = "train"
TASK3_NAME = "strong_generalization"
TASK3_DESCRIPTION = "强泛化：没见过的单词，没见过的风格"
TASK3_WORDS_START = 17000          
TASK3_WORDS_END = 20000
TASK3_STYLE_SOURCE = "test"      
TASK3_TEST_DIRS = "test1"   

EVAL_BATCH_SIZE = 16

SAVE_VISUALIZATION_SAMPLES = True
NUM_VIS_SAMPLES_PER_TASK = 5    

CALCULATE_PSNR = True
CALCULATE_SSIM = True
CALCULATE_MSE = True
EVAL_CHECKPOINT_PATH = f"outputs/{EXP_NAME}/checkpoints/best_model.pth"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

def create_directories():
    os.makedirs(CHECKPOINT_DIR, exist_ok=True)
    os.makedirs(SAMPLE_DIR, exist_ok=True)
    os.makedirs(EVALUATION_DIR, exist_ok=True)
create_directories()
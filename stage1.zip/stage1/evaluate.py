import os
import torch
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader
from torchvision import transforms
from PIL import Image
from tqdm import tqdm
import csv
import argparse

import config
from convnextgan2 import StyleTransferGAN
class ExhaustiveTestDataset(torch.utils.data.Dataset):
    def __init__(self, images, labels, transform=None):
        self.transform = transform
        self.normalize = transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        self.samples = []

        print(f"\n🔍 正在扫描并展平数据集 (共 {len(images)} 个原始图像文件)...")
        for img_path in tqdm(images, desc="展平进度", leave=False):
            filename = os.path.basename(img_path).split('.')[0]
            try:
                indexp = int(''.join(filter(str.isdigit, filename))) 
            except ValueError:
                continue
                
            label_str = labels[indexp]

            with Image.open(img_path) as img:
                width, height = img.size
                max_rows = height // config.ROW_HEIGHT
            if max_rows > 1:
                for row in range(1, max_rows):
                    self.samples.append((img_path, row, label_str))
            else:
                self.samples.append((img_path, 0, label_str))
                
        print(f"✅ 扫描完成！共提取出 {len(self.samples)} 个绝对固定的测试样本。\n")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        img_path, row, label_str = self.samples[index]
        image = Image.open(img_path).convert("RGB")
        refimg = image.crop((0, 0, config.IMAGE_WIDTH, config.ROW_HEIGHT))
        retimage = image.crop((0, row * config.ROW_HEIGHT, config.IMAGE_WIDTH, (row + 1) * config.ROW_HEIGHT))

        if self.transform:
            retimage = self.transform(retimage)
            refimg = self.transform(refimg)
        retimage = self.normalize(retimage)
        refimg = self.normalize(refimg)
        return retimage, refimg, 0, 0, img_path, label_str, row

def calculate_pixel_metrics(fake_b, real_b, threshold=0.5):
    fake_b = (fake_b + 1) / 2.0
    real_b = (real_b + 1) / 2.0
    fake_bin = (fake_b > threshold).float()
    real_bin = (real_b > threshold).float()

    tp = (fake_bin * real_bin).sum().item()         
    fp = (fake_bin * (1 - real_bin)).sum().item()   
    fn = ((1 - fake_bin) * real_bin).sum().item()   

    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    f1 = 2 * precision * recall / (precision + recall + 1e-8)

    return precision, recall, f1

def build_task_dataloader(image_dirs, label_path, word_start, word_end):
    image_files = []
    for d in image_dirs:
        if os.path.exists(d):
            image_files.extend([os.path.join(d, f) for f in os.listdir(d) if f.endswith(('.jpg', '.png'))])

    with open(label_path, 'r', encoding='utf-8') as f:
        labels = [line.strip().split(",")[config.LABEL_COLUMN_ROMAN].upper() for i, line in enumerate(f) if i >= 1]

    filtered_images = []
    for img_path in image_files:
        filename = os.path.basename(img_path).split('.')[0]
        try:
            indexp = int(''.join(filter(str.isdigit, filename))) 
        except ValueError:
            continue
            
        if word_start <= indexp < word_end:
            filtered_images.append(img_path)

    transform = transforms.Compose([transforms.ToTensor()])

    dataset = ExhaustiveTestDataset(filtered_images, labels, transform=transform)
    dataloader = DataLoader(dataset, batch_size=config.EVAL_BATCH_SIZE, shuffle=False, num_workers=4)
    
    return dataloader, len(dataset)

def evaluate_task(model, dataloader, task_name, output_dir):
    print(f"🚀 开始评估任务: {task_name}")
    model.generator.eval()
    
    total_f1, total_precision, total_recall = 0, 0, 0
    count = 0
    worst_samples = []

    with torch.no_grad():
        for real_A, real_B, _, _, _, labels, rows in tqdm(dataloader, desc=task_name):
            real_A = real_A.to(config.DEVICE)
            real_B = real_B.to(config.DEVICE)

            fake_B = model.generator(real_A)

            for i in range(real_A.size(0)):
                p, r, f1 = calculate_pixel_metrics(fake_B[i], real_B[i])
                
                total_precision += p
                total_recall += r
                total_f1 += f1
                count += 1

                img_A = real_A[i].cpu()
                img_fake = fake_B[i].cpu()
                img_real = real_B[i].cpu()
                
                label = labels[i] if isinstance(labels, (list, tuple)) else labels
                row_idx = rows[i].item() if isinstance(rows, torch.Tensor) else rows[i]
                
                worst_samples.append((f1, img_A, img_fake, img_real, label, p, r, row_idx))

    avg_p = total_precision / count if count > 0 else 0
    avg_r = total_recall / count if count > 0 else 0
    avg_f1 = total_f1 / count if count > 0 else 0

    print(f"📊 {task_name} 结果 (样本数: {count}):")
    print(f"  - 平均精确率 (防毛刺): {avg_p:.4f}")
    print(f"  - 平均召回率 (防断笔): {avg_r:.4f}")
    print(f"  - 平均 F1-Score (综合): {avg_f1:.4f}")

    worst_samples.sort(key=lambda x: x[0])
    top_100_worst = worst_samples[:100]

    worst_dir = os.path.join(output_dir, f"{task_name}_worst_100")
    os.makedirs(worst_dir, exist_ok=True)
    
    print(f"💾 正在保存 {task_name} 最差的 100 张样本对...")
    
    for rank, (f1, img_A, img_fake, img_real, label, p, r, row_idx) in enumerate(top_100_worst):
        fig, axes = plt.subplots(1, 3, figsize=(15, 3))
        
        axes[0].imshow(np.clip(((img_A + 1) / 2).permute(1, 2, 0).numpy(), 0, 1))
        axes[0].set_title(f'Input (L: {label} | R: {row_idx})')
        axes[0].axis('off')

        axes[1].imshow(np.clip(((img_fake + 1) / 2).permute(1, 2, 0).numpy(), 0, 1))
        axes[1].set_title(f'Generated\n(F1: {f1:.3f}, P: {p:.3f}, R: {r:.3f})')
        axes[1].axis('off')

        axes[2].imshow(np.clip(((img_real + 1) / 2).permute(1, 2, 0).numpy(), 0, 1))
        axes[2].set_title('Real Target')
        axes[2].axis('off')

        plt.tight_layout()
        plt.savefig(os.path.join(worst_dir, f"rank_{rank+1:03d}_f1_{f1:.3f}_{label}_r{row_idx}.png"))
        plt.close()

    return avg_p, avg_r, avg_f1

def main():
    parser = argparse.ArgumentParser(description="满文风格迁移 - 评估脚本")
    parser.add_argument('--tasks', type=int, nargs='+', default=[1, 2, 3], help="指定任务(1, 2, 3)")
    parser.add_argument('--test_dirs', type=str, nargs='+', default=['test1', 'test2'], choices=['test1', 'test2'])
    args = parser.parse_args()

    print("=" * 60)
    print("📋 满文手写体 - 严格前景掩码评估 (方案B穷举版)")
    print(f"🎯 当前运行任务: Task {args.tasks}")
    print(f"📂 当前使用测试集: {args.test_dirs}")
    print("=" * 60)

    model = StyleTransferGAN(device=config.DEVICE)
    checkpoint_path = config.EVAL_CHECKPOINT_PATH
    
    print(f"🔄 正在加载指定模型权重: {checkpoint_path}")
    if not os.path.exists(checkpoint_path):
        print(f"❌ 找不到权重文件: {checkpoint_path}")
        return
    model.load_checkpoint(checkpoint_path)

    eval_out_dir = config.EVALUATION_DIR
    os.makedirs(eval_out_dir, exist_ok=True)

    results = []
    target_test_dirs = []
    if 'test1' in args.test_dirs: target_test_dirs.append(config.TEST_IMAGE_DIR_1)
    if 'test2' in args.test_dirs: target_test_dirs.append(config.TEST_IMAGE_DIR_2)

    if 1 in args.tasks:
        dl1, cnt1 = build_task_dataloader(target_test_dirs, config.LABEL_FILE, config.TASK1_WORDS_START, config.TASK1_WORDS_END)
        if cnt1 > 0:
            p1, r1, f1_1 = evaluate_task(model, dl1, "Task1_Style_Generalization", eval_out_dir)
            results.append(["Task 1 (Style Gen)", p1, r1, f1_1])

    if 2 in args.tasks:
        dl2, cnt2 = build_task_dataloader([config.TRAIN_IMAGE_DIR], config.LABEL_FILE, config.TASK2_WORDS_START, config.TASK2_WORDS_END)
        if cnt2 > 0:
            p2, r2, f1_2 = evaluate_task(model, dl2, "Task2_Word_Generalization", eval_out_dir)
            results.append(["Task 2 (Word Gen)", p2, r2, f1_2])

    if 3 in args.tasks:
        dl3, cnt3 = build_task_dataloader(target_test_dirs, config.LABEL_FILE, config.TASK3_WORDS_START, config.TASK3_WORDS_END)
        if cnt3 > 0:
            p3, r3, f1_3 = evaluate_task(model, dl3, "Task3_Strong_Generalization", eval_out_dir)
            results.append(["Task 3 (Strong Gen)", p3, r3, f1_3])

    if results:
        tasks_str = "".join(map(str, args.tasks))
        dirs_str = "_".join(args.test_dirs)
        csv_name = f"eval_summary_T{tasks_str}_{dirs_str}.csv"
        csv_path = os.path.join(eval_out_dir, csv_name)
        
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(["Task", "Precision (防毛刺)", "Recall (防断笔)", "F1-Score (综合)"])
            writer.writerows(results)
        
        print("\n✅ 评估全部完成！")
        print(f"📊 评估总结已保存至: {csv_path}")

if __name__ == "__main__":
    main()
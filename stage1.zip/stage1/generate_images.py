import os
import torch
import argparse
from PIL import Image
import torchvision.transforms as transforms
from tqdm import tqdm
import config
from convnextgan2 import StyleTransferGAN

def get_image_files(directory):
    files = {}
    if not os.path.exists(directory):
        return files
    for f in os.listdir(directory):
        if f.endswith(('.jpg', '.png')):
            try:
                indexp = int(''.join(filter(str.isdigit, f.split('.')[0])))
                files[indexp] = os.path.join(directory, f)
            except ValueError:
                continue
    return files

def main():
    parser = argparse.ArgumentParser(description="满文手写体 - 批量生成任务图像脚本")
    parser.add_argument('--task', type=int, required=True, choices=[1, 2, 3], help="指定任务(1, 2, 3)")
    parser.add_argument('--checkpoint', type=str, default=config.EVAL_CHECKPOINT_PATH, help="模型权重路径")
    args = parser.parse_args()

    print("=" * 60)
    print(f"🚀 开始生成 Task {args.task} 的修复图像")
    print(f"📦 使用 SOTA 模型: {args.checkpoint}")
    print("=" * 60)

    if args.task == 1:
        word_start, word_end = config.TASK1_WORDS_START, config.TASK1_WORDS_END
    elif args.task == 2:
        word_start, word_end = config.TASK2_WORDS_START, config.TASK2_WORDS_END
    elif args.task == 3:
        word_start, word_end = config.TASK3_WORDS_START, config.TASK3_WORDS_END

    model = StyleTransferGAN(device=config.DEVICE)
    if not os.path.exists(args.checkpoint):
        print(f"❌ 找不到权重文件: {args.checkpoint}")
        return
    model.load_checkpoint(args.checkpoint)
    model.generator.eval()

    output_base_dir = os.path.join(f"outputs/{config.EXP_NAME}/task{args.task}_generated")
    for i in range(1, 9):
        os.makedirs(os.path.join(output_base_dir, f"font{i}"), exist_ok=True)
        os.makedirs(os.path.join(output_base_dir, f"input_font{i}"), exist_ok=True)

    test1_files = get_image_files(config.TEST_IMAGE_DIR_1)
    test2_files = get_image_files(config.TEST_IMAGE_DIR_2)

    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])
    to_pil = transforms.ToPILImage()

    img_counter = 1  
    
    valid_indices = [idx for idx in test1_files.keys() if word_start <= idx < word_end]
    valid_indices.sort()
    
    if not valid_indices:
        print(f"⚠️ 在 [{word_start}, {word_end}) 范围内未找到测试图像！")
        return

    print(f"🔍 找到 {len(valid_indices)} 个匹配的单词，准备执行手写归一化...")

    with torch.no_grad():
        for idx in tqdm(valid_indices, desc=f"Task {args.task} 生成进度"):
            if idx not in test1_files or idx not in test2_files:
                continue
                
            image1 = Image.open(test1_files[idx]).convert("RGB")
            image2 = Image.open(test2_files[idx]).convert("RGB")
            for row in range(1, 5):
                font_idx_1 = row
                input_pil_1 = image1.crop((0, row * config.ROW_HEIGHT, config.IMAGE_WIDTH, (row + 1) * config.ROW_HEIGHT))
                input_tensor_1 = transform(input_pil_1).unsqueeze(0).to(config.DEVICE)
                fake_B_tensor_1 = model.generator(input_tensor_1)
                fake_B_pil_1 = to_pil(torch.clamp((fake_B_tensor_1.squeeze(0) + 1.0) / 2.0, 0, 1).cpu())
                fake_B_pil_1.save(os.path.join(output_base_dir, f"font{font_idx_1}", f"{idx}.png"))
                input_pil_1.save(os.path.join(output_base_dir, f"input_font{font_idx_1}", f"{img_counter}.jpg"))
                font_idx_2 = row + 4
                input_pil_2 = image2.crop((0, row * config.ROW_HEIGHT, config.IMAGE_WIDTH, (row + 1) * config.ROW_HEIGHT))
                input_tensor_2 = transform(input_pil_2).unsqueeze(0).to(config.DEVICE)
                fake_B_tensor_2 = model.generator(input_tensor_2)
                fake_B_pil_2 = to_pil(torch.clamp((fake_B_tensor_2.squeeze(0) + 1.0) / 2.0, 0, 1).cpu())
                fake_B_pil_2.save(os.path.join(output_base_dir, f"font{font_idx_2}", f"{idx}.png"))
                input_pil_2.save(os.path.join(output_base_dir, f"input_font{font_idx_2}", f"{idx}.png"))
            
            img_counter += 1

    print(f"\n✅ 生成完毕！所有图像已按要求保存在: {output_base_dir}")

if __name__ == "__main__":
    main()
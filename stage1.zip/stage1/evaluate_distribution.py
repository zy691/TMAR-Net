import os
import torch
from torch.utils.data import DataLoader
from torchvision import transforms
from PIL import Image
from tqdm import tqdm
import argparse
import config
from convnextgan2 import StyleTransferGAN

class ExhaustiveTestDataset(torch.utils.data.Dataset):
    def __init__(self, images, labels, transform=None):
        self.transform = transform
        self.normalize = transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        self.samples = []

        print(f"\n🔍 正在扫描并展平数据集 (共 {len(images)} 个原始图像文件)...")
        for img_path in tqdm(images, desc="展平进度", leave=False):
            filename = os.path.basename(img_path).split('.')[0]
            try:
                indexp = int(''.join(filter(str.isdigit, filename))) 
            except ValueError:
                continue
                
            label_str = labels[indexp]
            
            with Image.open(img_path) as img:
                width, height = img.size
                max_rows = height // config.ROW_HEIGHT
            
            if max_rows > 1:
                for row in range(1, max_rows):
                    self.samples.append((img_path, row, label_str))
            else:
                self.samples.append((img_path, 0, label_str))
                
        print(f"✅ 扫描完成！共提取出 {len(self.samples)} 个绝对固定的测试样本。\n")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        img_path, row, label_str = self.samples[index]
        image = Image.open(img_path).convert("RGB")
        
        refimg = image.crop((0, 0, config.IMAGE_WIDTH, config.ROW_HEIGHT))
        retimage = image.crop((0, row * config.ROW_HEIGHT, config.IMAGE_WIDTH, (row + 1) * config.ROW_HEIGHT))

        if self.transform:
            retimage = self.transform(retimage)
            refimg = self.transform(refimg)

        retimage = self.normalize(retimage)
        refimg = self.normalize(refimg)

        return retimage, refimg, 0, 0, img_path, label_str, row

def calculate_pixel_metrics(fake_b, real_b, threshold=0.5):
    fake_b = (fake_b + 1) / 2.0
    real_b = (real_b + 1) / 2.0
    fake_bin = (fake_b > threshold).float()
    real_bin = (real_b > threshold).float()

    tp = (fake_bin * real_bin).sum().item()
    fp = (fake_bin * (1 - real_bin)).sum().item()
    fn = ((1 - fake_bin) * real_bin).sum().item()

    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    f1 = 2 * precision * recall / (precision + recall + 1e-8)
    return f1

def build_test_dataloader(image_dirs, word_start, word_end):
    image_files = []
    for d in image_dirs:
        if os.path.exists(d):
            image_files.extend([os.path.join(d, f) for f in os.listdir(d) if f.endswith(('.jpg', '.png'))])

    with open(config.LABEL_FILE, 'r', encoding='utf-8') as f:
        labels = [line.strip().split(",")[config.LABEL_COLUMN_ROMAN].upper() for i, line in enumerate(f) if i >= 1]

    filtered_images = []
    for img_path in image_files:
        filename = os.path.basename(img_path).split('.')[0]
        try:
            indexp = int(''.join(filter(str.isdigit, filename))) 
        except ValueError:
            continue
        if word_start <= indexp < word_end:
            filtered_images.append(img_path)

    transform = transforms.Compose([transforms.ToTensor()])
    dataset = ExhaustiveTestDataset(filtered_images, labels, transform=transform)
    dataloader = DataLoader(dataset, batch_size=config.EVAL_BATCH_SIZE, shuffle=False, num_workers=4)
    
    return dataloader, len(dataset)

def main():
    parser = argparse.ArgumentParser(description="满文风格迁移 - 分布统计")
    parser.add_argument('--tasks', type=int, default=3, choices=[1, 2, 3], help="指定要统计分布的任务 (1, 2, 3)，默认 3")
    parser.add_argument('--test_dirs', type=str, nargs='+', default=['test1', 'test2'], choices=['test1', 'test2'])
    args = parser.parse_args()

    print("=" * 60)
    print(f"📊 满文手写体 - F1 相似度区间分布统计 (Task {args.tasks} 穷举版)")
    print(f"📂 当前使用测试集: {args.test_dirs}")
    print("=" * 60)

    model = StyleTransferGAN(device=config.DEVICE)

    checkpoint_path = config.EVAL_CHECKPOINT_PATH
    
    print(f"🔄 正在加载指定模型权重: {checkpoint_path}")
    if not os.path.exists(checkpoint_path):
        print(f"❌ 找不到权重文件: {checkpoint_path}")
        return
    model.load_checkpoint(checkpoint_path)
    model.generator.eval()

    target_test_dirs = []
    if args.tasks == 2:
        target_test_dirs = [config.TRAIN_IMAGE_DIR]
        word_start, word_end = config.TASK2_WORDS_START, config.TASK2_WORDS_END
    else:
        if 'test1' in args.test_dirs: target_test_dirs.append(config.TEST_IMAGE_DIR_1)
        if 'test2' in args.test_dirs: target_test_dirs.append(config.TEST_IMAGE_DIR_2)
        
        if args.tasks == 1:
            word_start, word_end = config.TASK1_WORDS_START, config.TASK1_WORDS_END
        else:
            word_start, word_end = config.TASK3_WORDS_START, config.TASK3_WORDS_END
    dataloader, total_images = build_test_dataloader(target_test_dirs, word_start, word_end)
    
    if total_images == 0:
        print("⚠️ 未找到任何测试数据，请检查路径配置！")
        return

    distribution = {">= 99%": 0, "95% - 99%": 0, "90% - 95%": 0, "80% - 90%": 0, "70% - 80%": 0, "60% - 70%": 0, "50% - 60%": 0, "< 50%": 0}

    print(f"\n🚀 开始评估，共 {total_images} 张绝对测试样本...")
    total_f1 = 0
    
    with torch.no_grad():
        for real_A, real_B, _, _, _, _, _ in tqdm(dataloader, desc="评估进度"):
            real_A = real_A.to(config.DEVICE)
            real_B = real_B.to(config.DEVICE)

            fake_B = model.generator(real_A)

            for i in range(real_A.size(0)):
                f1 = calculate_pixel_metrics(fake_B[i], real_B[i])
                total_f1 += f1
                f1_pct = f1 * 100 

                if f1_pct >= 99.0: distribution[">= 99%"] += 1
                elif f1_pct >= 95.0: distribution["95% - 99%"] += 1
                elif f1_pct >= 90.0: distribution["90% - 95%"] += 1
                elif f1_pct >= 80.0: distribution["80% - 90%"] += 1
                elif f1_pct >= 70.0: distribution["70% - 80%"] += 1
                elif f1_pct >= 60.0: distribution["60% - 70%"] += 1
                elif f1_pct >= 50.0: distribution["50% - 60%"] += 1
                else: distribution["< 50%"] += 1

    avg_f1 = (total_f1 / total_images) * 100
    
    print("\n" + "=" * 60)
    print("📈 最终分布统计报告")
    print("=" * 60)
    print(f"总计评估样本 (精确穷举): {total_images} 张")
    print(f"平均 F1 相似度: {avg_f1:.2f}%\n")
    print(f"{'相似度区间':<15} | {'数量':<8} | {'占比':<10}")
    print("-" * 45)
    
    for bucket, count in distribution.items():
        percentage = (count / total_images) * 100 if total_images > 0 else 0
        bar = "█" * int(percentage / 2) 
        print(f"{bucket:<15} | {count:<8} | {percentage:>5.1f}% {bar}")
    
    print("=" * 60)
    
    under_99 = total_images - distribution[">= 99%"]
    print(f"💡 结论速览：共有 {under_99} 张 ({under_99/total_images*100:.1f}%) 图像的相似度在 99% 以下。")

if __name__ == "__main__":
    main()
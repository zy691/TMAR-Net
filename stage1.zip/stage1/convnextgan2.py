import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import os
import glob
import numpy as np
from einops import rearrange
from timm.models.convnext import ConvNeXt
import random
import matplotlib.pyplot as plt
from torch.cuda.amp import autocast, GradScaler
from torch import Tensor
from my_dataset_singlefile import MyDataSet
import time
import torchvision.models as models
import config
def seed_everything(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

class LayerNorm2d(nn.LayerNorm):
    def forward(self, x: Tensor) -> Tensor:
        x = x.permute(0, 2, 3, 1)
        x = F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        x = x.permute(0, 3, 1, 2)
        return x

class VGGFeatureExtractor(nn.Module):
    def __init__(self, feature_layer=34):
        super(VGGFeatureExtractor, self).__init__()
        vgg19 = models.vgg19(weights=models.VGG19_Weights.DEFAULT).features
        self.features = nn.Sequential(*list(vgg19.children())[:(feature_layer + 1)])
        for param in self.parameters():
            param.requires_grad = False

    def forward(self, x):
        x = (x + 1.0) / 2.0
        mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1).to(x.device)
        std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1).to(x.device)
        x = (x - mean) / std
        return self.features(x)

def create_dataset(image_dir, label_path, transform, skip_images=[], train=True):
    image_files = [f for f in os.listdir(image_dir) if f.endswith(('.jpg', '.jpeg', '.png', '.bmp'))]
    labels = []

    with open(label_path, 'r', encoding='utf-8') as f:
        content = f.readlines()

    for i, line in enumerate(content):
        if i >= 1:
            labels.append(line.strip().split(",")[config.LABEL_COLUMN_ROMAN].upper())

    print(f"Number of images: {len(image_files)}")
    print(f"Number of labels: {len(labels)}")

    if len(image_files) != len(labels):
        raise ValueError("图像文件数量和标签数量不一致！请检查数据。")

    filtered_image_files = []
    filtered_labels = []

    for i in range(len(image_files)):
        img_file = image_files[i]

        img_path = os.path.join(image_dir, img_file)
        with Image.open(img_path) as img:
            width, height = img.size
            if width != config.IMAGE_WIDTH or height not in config.TRAIN_VALID_HEIGHTS:
                print(f"Skipping image due to size mismatch: {img_file}, size: {width}x{height}")
                continue

        filtered_image_files.append(img_path)
        filtered_labels.append(labels[i].rstrip())

    print(f"Number of images after filtering: {len(filtered_image_files)}")

    if len(filtered_image_files) != len(filtered_labels):
        raise ValueError("过滤后的图像和标签数量不一致！")

    return MyDataSet(
        images=filtered_image_files,
        labels=filtered_labels,
        transform=transform,
        train=train
    )


def build_data_transform():
    transform_list = []

    if config.USE_PERSPECTIVE:
        transform_list.append(
            transforms.RandomPerspective(config.PERSPECTIVE_DISTORTION_SCALE)
        )

    if config.USE_GAUSSIAN_BLUR:
        transform_list.append(
            transforms.GaussianBlur(
                kernel_size=config.GAUSSIAN_KERNEL_SIZE,
                sigma=(config.GAUSSIAN_SIGMA_MIN, config.GAUSSIAN_SIGMA_MAX)
            )
        )

    if config.USE_ROTATION:
        transform_list.append(
            transforms.RandomRotation(degrees=config.ROTATION_DEGREES)
        )

    transform_list.append(transforms.ToTensor())
    return transforms.Compose(transform_list)

class ConvNeXtBlock(nn.Module):
    def __init__(self, dim, expansion_rate=4, drop_path=0.):
        super().__init__()
        self.dwconv = nn.Conv2d(dim, dim, kernel_size=7, padding=3, groups=dim)
        self.norm = nn.LayerNorm(dim, eps=1e-6)
        self.pwconv1 = nn.Linear(dim, dim * expansion_rate)
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(dim * expansion_rate, dim)
        self.gamma = nn.Parameter(torch.ones((dim)), requires_grad=True) if drop_path > 0. else None

    def forward(self, x):
        input = x
        x = self.dwconv(x)
        x = rearrange(x, 'b c h w -> b h w c')
        x = self.norm(x)
        x = self.pwconv1(x)
        x = self.act(x)
        x = self.pwconv2(x)

        if self.gamma is not None:
            x = x * self.gamma

        x = rearrange(x, 'b h w c -> b c h w')
        x = input + x
        return x

class SelfAttentionBlock(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.query_conv = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.key_conv = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.value_conv = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        B, C, H, W = x.size()
        proj_query = self.query_conv(x).view(B, -1, W * H).permute(0, 2, 1)
        proj_key = self.key_conv(x).view(B, -1, W * H)
        scale_factor = (C // 8) ** -0.5
        energy = torch.bmm(proj_query, proj_key) * scale_factor
        
        attention = self.softmax(energy)
        proj_value = self.value_conv(x).view(B, -1, W * H)
        out = torch.bmm(proj_value, attention.permute(0, 2, 1))
        out = out.view(B, C, H, W)
        out = self.gamma * out + x
        return out

class ConvNeXtGenerator(nn.Module):
    def __init__(self,
                 input_channels=None,
                 output_channels=None,
                 dims=None,
                 depths=None,
                 drop_path_rate=None):
        super().__init__()

        input_channels = input_channels or config.GENERATOR_INPUT_CHANNELS
        output_channels = output_channels or config.GENERATOR_OUTPUT_CHANNELS
        dims = dims or config.GENERATOR_DIMS
        depths = depths or config.GENERATOR_DEPTHS
        drop_path_rate = drop_path_rate or config.GENERATOR_DROP_PATH_RATE

        self.down1 = nn.Sequential(
            nn.Conv2d(input_channels, dims[0], kernel_size=7, stride=1, padding=3),
            LayerNorm2d(dims[0], eps=1e-6),
            *[ConvNeXtBlock(dims[0], drop_path=drop_path_rate) for _ in range(depths[0])]
        )

        self.down2 = nn.Sequential(
            nn.Conv2d(dims[0], dims[1], kernel_size=4, stride=2, padding=1),
            LayerNorm2d(dims[1], eps=1e-6),
            *[ConvNeXtBlock(dims[1], drop_path=drop_path_rate) for _ in range(depths[1])]
        )

        self.down3 = nn.Sequential(
            nn.Conv2d(dims[1], dims[2], kernel_size=4, stride=2, padding=1),
            LayerNorm2d(dims[2], eps=1e-6),
            *[ConvNeXtBlock(dims[2], drop_path=drop_path_rate) for _ in range(depths[2])]
        )

        self.down4 = nn.Sequential(
            nn.Conv2d(dims[2], dims[3], kernel_size=4, stride=2, padding=1),
            LayerNorm2d(dims[3], eps=1e-6),
            *[ConvNeXtBlock(dims[3], drop_path=drop_path_rate) for _ in range(depths[3])]
        )

        self.bottleneck_attn = SelfAttentionBlock(dims[3])

        self.up4 = nn.Sequential(
            *[ConvNeXtBlock(dims[3], drop_path=drop_path_rate) for _ in range(depths[3])],
            nn.ConvTranspose2d(dims[3], dims[2], kernel_size=4, stride=2, padding=1)
        )

        self.up3 = nn.Sequential(
            *[ConvNeXtBlock(dims[2] * 2, drop_path=drop_path_rate) for _ in range(depths[2])],
            nn.ConvTranspose2d(dims[2] * 2, dims[1], kernel_size=4, stride=2, padding=1)
        )

        self.up2 = nn.Sequential(
            *[ConvNeXtBlock(dims[1] * 2, drop_path=drop_path_rate) for _ in range(depths[1])],
            nn.ConvTranspose2d(dims[1] * 2, dims[0], kernel_size=4, stride=2, padding=1)
        )

        self.up1 = nn.Sequential(
            *[ConvNeXtBlock(dims[0] * 2, drop_path=drop_path_rate) for _ in range(depths[0])],
            nn.Conv2d(dims[0] * 2, 64, kernel_size=3, padding=1)
        )

        self.output = nn.Sequential(
            nn.Conv2d(64, 32, kernel_size=3, padding=1),
            nn.GELU(),
            nn.Conv2d(32, output_channels, kernel_size=3, padding=1),
            nn.Tanh()
        )
    def forward(self, x):
        d1 = self.down1(x)
        d2 = self.down2(d1)
        d3 = self.down3(d2)
        d4 = self.down4(d3)
        d4 = self.bottleneck_attn(d4)
        u4 = self.up4(d4)
        u4 = torch.cat([u4, d3], dim=1)
        u3 = self.up3(u4)
        u3 = torch.cat([u3, d2], dim=1)
        u2 = self.up2(u3)
        u2 = torch.cat([u2, d1], dim=1)

        u1 = self.up1(u2)
        output = self.output(u1)
        return output

class ConvDiscriminator(nn.Module):
    def __init__(self, input_channels=6, base_channels=64):
        super().__init__()
        self.model = nn.Sequential(
            nn.utils.spectral_norm(nn.Conv2d(input_channels, base_channels, kernel_size=4, stride=2, padding=1)),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.utils.spectral_norm(nn.Conv2d(base_channels, base_channels * 2, kernel_size=4, stride=2, padding=1)),
            nn.InstanceNorm2d(base_channels * 2),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.utils.spectral_norm(nn.Conv2d(base_channels * 2, base_channels * 4, kernel_size=4, stride=2, padding=1)),
            nn.InstanceNorm2d(base_channels * 4),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.utils.spectral_norm(nn.Conv2d(base_channels * 4, base_channels * 8, kernel_size=4, stride=1, padding=1)),
            nn.InstanceNorm2d(base_channels * 8),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.Conv2d(base_channels * 8, 1, kernel_size=4, stride=1, padding=1)
        )

    def forward(self, x, y):
        img_input = torch.cat([x, y], dim=1)
        return self.model(img_input)

class StyleTransferGAN:
    def __init__(self, device=None):
        self.device = device or config.DEVICE
        self.generator = ConvNeXtGenerator().to(self.device)
        self.discriminator = ConvDiscriminator(
            input_channels=config.DISCRIMINATOR_INPUT_CHANNELS,
            base_channels=config.DISCRIMINATOR_BASE_CHANNELS
        ).to(self.device)
        self.vgg_extractor = VGGFeatureExtractor().to(self.device)
        self.vgg_extractor.eval()

        self.optimizer_G = torch.optim.Adam(self.generator.parameters(), lr=config.LR_G, betas=config.BETAS)
        self.optimizer_D = torch.optim.Adam(self.discriminator.parameters(), lr=config.LR_D, betas=config.BETAS)
        self.scaler_G = torch.cuda.amp.GradScaler() if config.USE_AMP else None
        self.scaler_D = torch.cuda.amp.GradScaler() if config.USE_AMP else None
        self.scheduler_G = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer_G, T_max=config.LR_SCHEDULER_T_MAX, eta_min=config.LR_SCHEDULER_ETA_MIN)
        self.scheduler_D = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer_D, T_max=config.LR_SCHEDULER_T_MAX, eta_min=config.LR_SCHEDULER_ETA_MIN)

        self.current_epoch = 0
        self.best_l1 = float('inf')

    def _scaler_scale(self, scaler, loss):
        if scaler is not None:
            return scaler.scale(loss)
        return loss

    def _scaler_step(self, scaler, optimizer):
        if scaler is not None:
            scaler.step(optimizer)
            scaler.update()
        else:
            optimizer.step()

    def _scaler_backward(self, scaler, loss):
        if scaler is not None:
            scaler.scale(loss).backward()
        else:
            loss.backward()

    def train_epoch(self, dataloader, epoch, num_epochs):
        g_losses, d_losses, l1_losses = [], [], []
        
        self.generator.train()
        self.discriminator.train()
        
        fixed_batch = None

        for i, (real_A, real_B, label_tensor, targets, image_path, label, indexp) in enumerate(dataloader):
            if i == 0:
                fixed_batch = (real_A.clone(), real_B.clone())
                
            real_A = real_A.to(self.device)
            real_B = real_B.to(self.device)

            self.optimizer_D.zero_grad()
            
            with torch.cuda.amp.autocast(enabled=config.USE_AMP):
                fake_B = self.generator(real_A)
                
                pred_real = self.discriminator(real_A, real_B)
                pred_fake = self.discriminator(real_A, fake_B.detach())
                
                loss_D_real = F.mse_loss(pred_real, torch.ones_like(pred_real))
                loss_D_fake = F.mse_loss(pred_fake, torch.zeros_like(pred_fake))
                d_loss = (loss_D_real + loss_D_fake) * 0.5

            if config.USE_AMP:
                self.scaler_D.scale(d_loss).backward()
                self.scaler_D.step(self.optimizer_D)
                self.scaler_D.update()
            else:
                d_loss.backward()
                self.optimizer_D.step()

            self.optimizer_G.zero_grad()
            
            with torch.cuda.amp.autocast(enabled=config.USE_AMP):
                pred_fake_G = self.discriminator(real_A, fake_B)

                g_adv_loss = F.mse_loss(pred_fake_G, torch.ones_like(pred_fake_G))

                weight_mask = torch.where(real_B > 0.0, 10.0, 1.0)

                raw_l1 = F.l1_loss(fake_B, real_B, reduction='none')

                weighted_l1 = raw_l1 * weight_mask

                batch_loss = weighted_l1.reshape(real_B.size(0), -1).mean(dim=1)

                ohem_ratio = 0.5 
                k = max(1, int(real_B.size(0) * ohem_ratio)) # 确保至少保留 1 个样本

                hard_loss, _ = torch.topk(batch_loss, k)
                
                l1_loss = hard_loss.mean() * config.LAMBDA_L1

                fake_features = self.vgg_extractor(fake_B)
                real_features = self.vgg_extractor(real_B)
                perceptual_loss = F.l1_loss(fake_features, real_features) * config.LAMBDA_PERCEPTUAL
                g_loss = g_adv_loss + l1_loss + perceptual_loss

            if config.USE_AMP:
                self.scaler_G.scale(g_loss).backward()
                torch.nn.utils.clip_grad_norm_(self.generator.parameters(), max_norm=config.GRAD_CLIP_MAX_NORM)
                self.scaler_G.step(self.optimizer_G)
                self.scaler_G.update()
            else:
                g_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.generator.parameters(), max_norm=config.GRAD_CLIP_MAX_NORM)
                self.optimizer_G.step()

            g_losses.append(g_loss.item())
            d_losses.append(d_loss.item())
            l1_losses.append(l1_loss.item())

            if i % config.LOG_INTERVAL == 0:
                print(f"[Epoch {epoch}/{num_epochs}] [Batch {i}/{len(dataloader)}] "
                      f"[D loss: {d_loss.item():.4f}] [G adv: {g_adv_loss.item():.4f}] [L1: {l1_loss.item():.4f}]")

        return np.mean(g_losses), np.mean(d_losses), np.mean(l1_losses), fixed_batch

    def train(self, dataloader, num_epochs=None):
        num_epochs = num_epochs or config.NUM_EPOCHS
        start_epoch = self.current_epoch

        for epoch in range(start_epoch, num_epochs):
            self.current_epoch = epoch

            g_loss, d_loss, l1_loss, fixed_batch = self.train_epoch(dataloader, epoch, num_epochs)

            self.scheduler_G.step()
            self.scheduler_D.step()

            print(f"Epoch {epoch}/{num_epochs} - G Loss: {g_loss:.4f}, D Loss: {d_loss:.4f}, L1 Loss: {l1_loss:.4f}, LR_G: {self.optimizer_G.param_groups[0]['lr']:.6f}")

            if (epoch + 1) % config.SAVE_INTERVAL == 0:
                self.save_checkpoint(os.path.join(config.CHECKPOINT_DIR, f'wgangp_epoch_{epoch}.pth'), epoch)

            if l1_loss < self.best_l1:
                self.best_l1 = l1_loss
                self.save_checkpoint(os.path.join(config.CHECKPOINT_DIR, 'best_model.pth'), epoch)
                print(f"  🏆 新的最佳模型！L1 Loss: {l1_loss:.4f}")

            if (epoch + 1) % config.SAVE_INTERVAL == 0:
                self.sample_images(fixed_batch, epoch, save_path=config.SAMPLE_DIR)

    def sample_images(self, fixed_batch, epoch, save_path=None, num_samples=None):
        save_path = save_path or config.SAMPLE_DIR
        num_samples = num_samples or config.NUM_SAMPLES

        self.generator.eval()

        real_A, real_B = fixed_batch
        real_A = real_A[:num_samples].to(self.device)
        real_B = real_B[:num_samples].to(self.device)

        with torch.no_grad():
            fake_B = self.generator(real_A)

        fig, axes = plt.subplots(num_samples, 3, figsize=(12, 4 * num_samples))
        if num_samples == 1:
            axes = axes.reshape(1, -1)

        for i in range(num_samples):
            img_A = real_A[i].cpu().detach()
            img_A = (img_A + 1) / 2
            axes[i, 0].imshow(np.clip(img_A.permute(1, 2, 0).numpy(), 0, 1))
            axes[i, 0].set_title('Input (Augmented)')
            axes[i, 0].axis('off')

            img_fake = fake_B[i].cpu().detach()
            img_fake = (img_fake + 1) / 2
            axes[i, 1].imshow(np.clip(img_fake.permute(1, 2, 0).numpy(), 0, 1))
            axes[i, 1].set_title('Generated')
            axes[i, 1].axis('off')

            img_real = real_B[i].cpu().detach()
            img_real = (img_real + 1) / 2
            axes[i, 2].imshow(np.clip(img_real.permute(1, 2, 0).numpy(), 0, 1))
            axes[i, 2].set_title('Real Target')
            axes[i, 2].axis('off')

        plt.tight_layout()
        os.makedirs(save_path, exist_ok=True)
        plt.savefig(f'{save_path}/epoch_{epoch}.png')
        plt.close()

        self.generator.train()

    def generate(self, input_image, skeleton):
        self.generator.eval()
        with torch.no_grad():
            output = self.generator(input_image.unsqueeze(0).to(self.device),
                                   skeleton.unsqueeze(0).to(self.device))
        return output.squeeze(0)

    def save_checkpoint(self, path, epoch):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        checkpoint_dict = {
            'epoch': epoch,
            'generator_state_dict': self.generator.state_dict(),
            'optimizer_G_state_dict': self.optimizer_G.state_dict(),
            'scheduler_G_state_dict': self.scheduler_G.state_dict(),
        }
        if config.USE_DISCRIMINATOR:
            checkpoint_dict.update({
                'discriminator_state_dict': self.discriminator.state_dict(),
                'optimizer_D_state_dict': self.optimizer_D.state_dict(),
                'scheduler_D_state_dict': self.scheduler_D.state_dict(),
            })
            
        torch.save(checkpoint_dict, path)
        print(f"Checkpoint saved to {path}")

    def load_checkpoint(self, path):
        checkpoint = torch.load(path, map_location=self.device) 
        self.generator.load_state_dict(checkpoint['generator_state_dict'])
        self.optimizer_G.load_state_dict(checkpoint['optimizer_G_state_dict'])
        self.scheduler_G.load_state_dict(checkpoint['scheduler_G_state_dict'])
        if config.USE_DISCRIMINATOR:
            if 'discriminator_state_dict' in checkpoint:
                self.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                self.optimizer_D.load_state_dict(checkpoint['optimizer_D_state_dict'])
                self.scheduler_D.load_state_dict(checkpoint['scheduler_D_state_dict'])
                print("   -> 判别器(D)的所有组件状态已成功从检查点中恢复")
            else:
                print("   ⚠️ 警告: 检查点中未找到判别器状态，判别器将进行随机初始化开始训练")
                
        self.current_epoch = checkpoint.get('epoch', 0) + 1
        print(f"Checkpoint loaded from {path} (resuming from epoch {self.current_epoch})")

def train_style_transfer():
    data_transform = build_data_transform()
    dataset = create_dataset(
        image_dir=config.TRAIN_IMAGE_DIR,
        label_path=config.LABEL_FILE,
        transform=data_transform,
        train=True
    )

    dataloader = DataLoader(
        dataset,
        batch_size=config.BATCH_SIZE,
        shuffle=True,
        num_workers=config.NUM_WORKERS,
        pin_memory=True,
        drop_last=True
    )

    model = StyleTransferGAN()

    if config.RESUME_FROM and os.path.exists(config.RESUME_FROM):
        model.load_checkpoint(config.RESUME_FROM)
    elif config.RESUME_FROM:
        print(f"⚠️ 检查点不存在: {config.RESUME_FROM}，将从头开始训练")

    model.train(dataloader)

    return model

def inference(model, input_image_path, output_path="output.jpg"):
    if isinstance(model, str):
        model_instance = StyleTransferGAN()
        model_instance.load_checkpoint(model)
        model = model_instance

    input_image = Image.open(input_image_path).convert('RGB')
    
    transform = transforms.Compose([
        transforms.Resize((config.ROW_HEIGHT, config.IMAGE_WIDTH)),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])
    
    input_tensor = transform(input_image).unsqueeze(0).to(config.DEVICE)

    model.generator.eval()
    with torch.no_grad():
        output_tensor = model.generator(input_tensor)

    output_tensor = output_tensor.squeeze(0).cpu()
    output_tensor = (output_tensor + 1) / 2
    output_image = transforms.ToPILImage()(output_tensor)

    output_image.save(output_path)
    print(f"Generated image saved to {output_path}")

    return output_image

def main():
    seed_everything(config.SEED) 
    print(f"Using device: {config.DEVICE}")
    config.print_config()
    print("Starting training...")
    model = train_style_transfer()

    final_path = os.path.join(config.CHECKPOINT_DIR, 'final_model.pth')
    model.save_checkpoint(final_path, config.NUM_EPOCHS - 1)

    print(f"\n✅ 训练完成！最终模型已保存至: {final_path}")

if __name__ == "__main__":
    main()